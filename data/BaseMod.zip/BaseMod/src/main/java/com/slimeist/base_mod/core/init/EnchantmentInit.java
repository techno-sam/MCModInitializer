package com.slimeist.base_mod.core.init;

public class EnchantmentInit {
}
