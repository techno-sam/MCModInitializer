package com.slimeist.base_mod.core.init;

import com.slimeist.base_mod.BaseMod;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryBuilder;

public class RegistryInit {
    //public static IForgeRegistry<ForceModifierRegistry> MODIFIER_REGISTRY;

    public static void registerAll(RegistryEvent.NewRegistry event) {
        /*RegistryBuilder<ForceModifierRegistry> registryBuilder = new RegistryBuilder<>();
        registryBuilder.setName(BaseMod.getId("modifier_registry"));
        registryBuilder.setType(ForceModifierRegistry.class);
        registryBuilder.setDefaultKey(BaseMod.getId("default_action"));
        MODIFIER_REGISTRY = registryBuilder.create();*/
    }
}
