package com.slimeist.base_mod.common;

import net.minecraft.world.World;

public class CommonProxy {

    public World getClientWorld() {
        return null;
    }

}
